       
#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>

int main(int argc, string argv[])
{
    if(argc != 2)
    {
         fprintf(stderr, "Usage: ./recover image\n");
        return 1;
    }
    
    
    char *infile = argv[1];
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", infile);
        return 2;
    }
    

   
  FILE* imgarr[50];
    
    bool jpegFound = false;
    int jpegs = 0, i =-1;

    
  
    while(true)
    {
      unsigned char buffer[512];
      int count = fread(&buffer, 512,1,inptr);
      if(count != 1 || feof(inptr))
      {
      
           fwrite(&buffer, count,1, imgarr[i]);
           fclose(imgarr[i]);
           fclose(inptr);
           break;
      
          
      }
      
      if(buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
      {
           if(i != -1)
           {
             fclose(imgarr[i]);
         
           }
        char filename[9];
        sprintf(filename, "%03i.jpg", jpegs);
        jpegs++;
        imgarr[++i] = fopen(filename, "w");
        if (imgarr[i]== NULL)
        {
          fprintf(stderr, "Could not open %s.\n", infile);
          return 2;
        }
        fwrite(&buffer, 512,1, imgarr[i]);
        jpegFound = true;
      }
      else if(jpegFound == true)
      {
        fwrite(&buffer, 512,1, imgarr[i]);
      }
    }
    
    

    return 0;
    
}