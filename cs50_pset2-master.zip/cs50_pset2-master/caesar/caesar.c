#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    
    if(argc >2 || argc ==1)
    {
        printf("Usage: ./ceasar k");
        return 1;
    }
    
    //assume that, if a user does provide a command-line argument, it will be a non-negative integer
   
    printf("plaintext:");
    string pltext= get_string();
    char ciphertext[100];

    char alphas[27] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    
    int k= atoi(argv[1]),i,j;          // position by which to rotate alphabets is stored in int k
    for(i=0; pltext[i] != '\0'; i++)
    {           
             
                if(isalpha(pltext[i])) // if its char is an alphabet
                {
                   
                   for(j=0; j<26;j++)
                   {
                       if(alphas[j] ==pltext[i])
                       {
                           break;
                       }
                       else if(toupper(alphas[j]) == pltext[i])
                       {
                           break;
                       }
                   }
                   int c = (j+k)%26;         
                   
                             if(isupper(pltext[i]))
                             {
                                 ciphertext[i] = toupper(alphas[c]);
                           
                             }
                             else if(islower(pltext[i]))
                             {
                                 ciphertext[i] = alphas[c];
                           
                             }
                           
                }
                else 
                    ciphertext[i] =pltext[i];
    }
      ciphertext[i] ='\0';
      printf("ciphertext:%s",ciphertext);
      printf("\n");
     return 0;
}