/**
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "dictionary.h"


#define BUCKETS 65536


node* hashtable[BUCKETS]={NULL};
int hash (char* word)                                //////////// hash function
 {
        
    // unsigned int hash = 0;
    // for (int i = 0, n = strlen(word); i < n; i++)
    //     hash = (hash << 5) ^ word[i];
    // return hash % BUCKETS;
    
    unsigned int h = 7;
    for (int i = 0; i < strlen(word); i++) 
    {
       h = h*31 + word[i];
    }
    return h% BUCKETS;
    
}


int dictionary_size = 0;
//SOURCE: https://stackoverflow.com/questions/2624192/good-hash-function-for-strings



/**
 * Loads dictionary into memory. Returns true if successful else false.
 */

bool load(const char *dictionary)
{
    
    char word[LENGTH+1];
    int index = 0;
    FILE* dict = fopen(dictionary, "r");
    if(dict == NULL)
    {
        printf("Failed to Load dictionary!\n");
        return false;
    }
    while(fscanf(dict, "%s", word) != EOF)
    {
        node* new_node = malloc(sizeof(node));
        if(new_node == NULL)
        {
            printf("Failed to create node!");
            return false;
        }
        
        strcpy(new_node->word, word);
        
        index = hash (word);
  
        
        if(index < BUCKETS)
        {
            
                new_node->next = hashtable[index];
                hashtable[index] = new_node;             // joining nodes in correct format
         
        }
        
        dictionary_size++;                             // counting words in dictionary
    }
    return true;          // successfully loaded dictionary
}


bool check(const char *word)
{
    
   char word2[LENGTH+1];
    
    for(int i=0; word[i] != '\0'; i++)                       // converting word letters to small case letters
    {
        if(word[i] >='A' && word[i] <='Z')
        {
            
            word2[i] = tolower(word[i]);
        }
        else
        {
            word2[i] = word[i];
        }
        word2[i+1]='\0';
    }
    int index = hash(word2);               // returns bucket number 
    
    
    if(index < BUCKETS)
    {
        node* head = hashtable[index];
        
        while(head != NULL)             // traversing through entire linked list
        {
           
            if(strcmp(head->word, word2) == 0)        // comparing given word with node's word
            {
             
                return true;
            }
            head = head->next;
        }
    }
    return false;
}



/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
   
    if(dictionary_size > 0)              // if loaded
    {
        return dictionary_size;
    }
    return 0;
}

/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void)
{
    int index = 0;
    while(index < BUCKETS)                // iterate through entire hash table
    {
        
        node* prev = NULL;
        node* curr = NULL;
        if(hashtable[index] != NULL)
        {
            curr = hashtable[index];
            while(curr != NULL)
            {
                prev =  curr;
                curr = prev->next;
                free(prev);
            }
        }
        index++;
    }
    return true;          // successfully unloaded
}








